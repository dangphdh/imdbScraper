# imdbScraper
## clone repo
  git clone https://github.com/dangphdh/imdbScraper.git
## Jump to folder
  - cd imdbScraper
## Install required dependencies
  - pip install requirements.txt
## Run project
  - python IMDB_crawler.py
## Database connection string
  - mongodb+srv://dangphdh:BDufqdVjZREfM7TQ@cluster0.qphz3fb.mongodb.net/test
